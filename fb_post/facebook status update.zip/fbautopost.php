<?php
include 'httpcurl.php';
include 'fbform.php';

$fbhomepage = 'http://m.facebook.com';
$username = "xxxxx";   // Insert your login email
$password = "xxxxx";   // Insert your password
$status = "Check it out at http://php8legs.com/!";

$pages = new FBform();
$pages->get($fbhomepage);  
$pages->fblogin($username, $password);
$pages->get($fbhomepage);
$pages->fbstatusupdate($status);

?>